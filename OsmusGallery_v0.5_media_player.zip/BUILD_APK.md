# Build APK

## Android Studio
Apri la cartella del progetto con Android Studio (JDK 17, SDK 35) e usa:
Build > Build App Bundle(s) / APK(s) > Build APK(s)

Output previsto:
`app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions
Il progetto include `.github/workflows/build-apk.yml`.
Caricalo in un repository GitHub, apri la scheda **Actions**, esegui **Build APK**
e scarica l'artifact `OsmusGallery-debug-apk`.
