# OsmusGallery v0.4

## Nuovo in v0.4
- Se la Cassaforte contiene file, **Disattiva protezione** non disattiva immediatamente la protezione.
- L'utente resta obbligatoriamente nella schermata **Nascosti/Cassaforte** e riceve un avviso con il numero di elementi presenti.
- La protezione resta attiva finché non viene premuto **Ho controllato, disattiva**.
- Se la Cassaforte è vuota, la disattivazione può procedere direttamente.

# Galleria — Osmus Studio

Galleria locale per Android con motore anti-duplicati. Nessuna rete, nessun
account, nessuna telemetria: il manifest non dichiara `INTERNET`, quindi
l'app non può contattare nulla nemmeno per errore.

## Come compilarla

1. Android Studio → **Open** → seleziona questa cartella.
2. Al primo avvio Studio scarica Gradle 8.9 e le dipendenze, e genera il
   wrapper. Servono JDK 17 (incluso in Studio) e SDK 35.
3. `Run ▶` su un dispositivo con Android 8.0 o superiore.

Non serve firmare nulla per provarla. Per un APK installabile su altri
telefoni: *Build → Generate Signed App Bundle / APK*.

## Cosa fa già

- Vista cartelle e vista "tutti gli elementi", da `MediaStore`
- Griglia con **pinch per cambiare la densità** delle colonne (2–7)
- Ordinamento: data ↑↓, nome, dimensione, tipo, casuale
- Anteprime ritagliate in quadrati o intere
- Viewer a schermo pieno: pager, pinch-zoom fino a 8x, doppio tap,
  pannello dettagli, condivisione, eliminazione
- Selezione multipla con pressione prolungata
- Aggiornamento automatico quando la libreria cambia (`ContentObserver`)
- **Motore anti-duplicati a tre stadi** (vedi sotto)
- Eliminazione sempre via cestino di sistema su Android 11+: recuperabile
  per 30 giorni

## Il motore anti-duplicati

**Stadio 1 — copie identiche.** Raggruppa per dimensione esatta, poi
calcola MD5 del contenuto (intero sotto 8 MB, testa+coda sopra). Costo
quasi nullo, trova i rinvii WhatsApp e i download ripetuti.

**Stadio 2 — immagini simili.** dHash a 64 bit: griglia 9×8 in scala di
grigi, confronto orizzontale fra pixel adiacenti. Invariante a
ricompressione, ridimensionamento e luminosità uniforme. La ricerca usa
**LSH a 8 bande da 8 bit**: si confrontano solo gli hash che collidono in
almeno una banda, invece delle n²/2 coppie.

**Stadio 3 — video e GIF.** Impronta = dHash di 7 fotogrammi campionati a
percentuali fisse della durata (10, 25, 40, 50, 60, 75, 90%). Pre-filtro
per durata ±2 s prima di qualsiasi confronto. Simili se almeno 5
fotogrammi su 7 corrispondono.

I gruppi transitivi (A≈B, B≈C ⇒ stesso gruppo) li risolve un union-find
con compressione di cammino.

### Cache incrementale

Le impronte finiscono in `fingerprints.db` (SQLite di sistema, non Room),
invalidate su `(size, date_modified)`. La prima analisi è lenta; le
successive toccano solo i file nuovi.

### Quale copia tenere

`DuplicateFinder.chooseKeeper` assegna un punteggio in quest'ordine:
risoluzione (peso 4× sui pixel), dimensione, penalità forte per le
cartelle derivate (WhatsApp, Telegram, Screenshots, Download…), bonus se
ha EXIF `DATE_TAKEN`, penalità per nomi tipo `(1)` o `copy`, e a parità
vince il file più vecchio.

Niente viene mai cancellato senza selezione esplicita, e il pulsante dice
"Sposta nel cestino", non "Elimina".

## Soglie da tarare

In `DuplicateFinder`:

| Parametro | Default | Effetto |
|---|---|---|
| `imageThreshold` | 10 | Distanza di Hamming per "immagini simili". 4 = quasi identiche, 14 = molto permissivo |
| `videoFrameThreshold` | 8 | Tolleranza per singolo fotogramma |
| `videoMinMatches` | 5 | Su 7 posizioni campionate |
| `videoDurationToleranceMs` | 2000 | Ampiezza del pre-filtro sulla durata |

Provale sulle tue foto vere: la soglia giusta dipende da quanti screenshot
e quante foto in raffica hai in libreria.

## Struttura

```
data/MediaRepository.kt     query MediaStore, album, cestino
data/FingerprintStore.kt    cache SQLite delle impronte
dedupe/Hashing.kt           dHash, impronta video, hash di contenuto
dedupe/DuplicateFinder.kt   pipeline a 3 stadi, LSH, union-find, keeper
ui/GalleryViewModel.kt      stato, selezione, scansione
ui/GridScreens.kt           album + griglia
ui/ViewerScreen.kt          viewer a schermo pieno
ui/DuplicatesScreen.kt      risultati e azioni
MainActivity.kt             permessi, routing, launcher del cestino
```

## Cosa non c'è ancora

Cartella privata con biometria, cestino proprio, ricerca, mappa EXIF,
presentazione, editor, rilevamento raffiche, punteggio qualità.


## Nascosti / Cassaforte (v0.2)
- Nascondi una singola foto, GIF o video dalla griglia o dal viewer.
- Nascondi un intero album/cartella dal menu dell'album.
- Sezione **Nascosti** separata dalla galleria normale.
- Crea e rinomina cartelle nascoste; elimina le cartelle vuote.
- Ripristina un singolo elemento, una selezione o un'intera cartella.
- OsmusGallery conserva nome, cartella originale, tipo e data per il ripristino.
- I contenuti della cassaforte non vengono esposti a MediaStore/altre gallerie.

**Nota importante:** la cassaforte usa lo spazio esterno privato dell'app. Prima di disinstallare OsmusGallery, rendere visibili/ripristinare i contenuti nascosti: Android può rimuovere lo spazio privato dell'app durante la disinstallazione.


## v0.3 - Protezione disinstallazione della Cassaforte
- Protezione opzionale tramite Amministratore dispositivo Android.
- Dopo il primo contenuto nascosto l'app propone l'attivazione della protezione.
- Finché è attiva, la rimozione dell'app richiede prima la disattivazione dell'amministratore.
- Alla richiesta di disattivazione viene mostrato un avviso se la Cassaforte contiene elementi.
- Nello stesso momento viene generata, se le notifiche sono consentite, una notifica con azione **Apri Cassaforte**.
- La schermata Nascosti mostra chiaramente se la protezione è attiva o disattiva.

Nota: Android non permette a un'app normale di aggiungere un pulsante personalizzato direttamente nel dialogo di disinstallazione di sistema.

## v0.5 - Viewer multimediale integrato

- Video riprodotti direttamente dentro OsmusGallery con AndroidX Media3 / ExoPlayer.
- Controlli video integrati: play/pausa, seek bar, tempo e controlli standard del player.
- Il video si mette in pausa automaticamente quando si passa a un altro elemento.
- GIF animate riprodotte nel viewer tramite decoder Coil dedicato.
- Foto con pinch-to-zoom e doppio tap 1x / 2.5x.
- Viewer unico per foto, GIF e video, compresi gli elementi della Cassaforte.
