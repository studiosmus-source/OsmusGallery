package com.osmus.gallery

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.io.File

/**
 * Protezione opzionale contro la disinstallazione accidentale.
 *
 * Android richiede che l'utente abiliti esplicitamente OsmusGallery come
 * amministratore dispositivo. Non vengono richieste policy invasive: l'admin
 * serve solo come barriera esplicita prima della disinstallazione.
 */
class DeviceAdminGuardReceiver : DeviceAdminReceiver() {

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence {
        val count = hiddenCount(context)
        postOpenVaultNotification(context, count)
        return if (count > 0) {
            "Attenzione: la Cassaforte di OsmusGallery contiene $count elementi. " +
                "Prima di rimuovere la protezione, apri la notifica “Apri Cassaforte” " +
                "e ripristina o esporta ciò che vuoi conservare."
        } else {
            "La protezione disinstallazione di OsmusGallery sta per essere disattivata."
        }
    }

    private fun hiddenCount(context: Context): Int {
        val root = File(context.getExternalFilesDir(null) ?: context.filesDir, "OsmusHidden")
        return root.walkTopDown().count {
            it.isFile && !it.name.endsWith(".osmusmeta") && !it.name.endsWith(".meta")
        }
    }

    private fun postOpenVaultNotification(context: Context, count: Int) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return

        val manager = context.getSystemService(NotificationManager::class.java)
        val channelId = "vault_protection"
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(
                NotificationChannel(
                    channelId,
                    "Protezione Cassaforte",
                    NotificationManager.IMPORTANCE_HIGH,
                ).apply {
                    description = "Avvisi prima della disattivazione della protezione Cassaforte"
                }
            )
        }

        val openIntent = Intent(context, MainActivity::class.java).apply {
            putExtra(MainActivity.EXTRA_OPEN_HIDDEN, true)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        val pending = PendingIntent.getActivity(
            context,
            1001,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        val body = if (count > 0) {
            "Ci sono $count elementi nascosti. Apri la Cassaforte prima di disinstallare OsmusGallery."
        } else {
            "Apri la Cassaforte prima di proseguire."
        }
        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Prima di disinstallare")
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pending)
            .addAction(0, "Apri Cassaforte", pending)
            .build()
        manager.notify(1001, notification)
    }
}
