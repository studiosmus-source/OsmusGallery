package com.osmus.gallery

import android.Manifest
import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.osmus.gallery.data.MediaItem
import com.osmus.gallery.data.MediaRepository
import com.osmus.gallery.ui.AlbumsScreen
import com.osmus.gallery.ui.DuplicatesScreen
import com.osmus.gallery.ui.GalleryViewModel
import com.osmus.gallery.ui.HiddenAlbumsScreen
import com.osmus.gallery.ui.PhotoGridScreen
import com.osmus.gallery.ui.ViewerScreen

private sealed interface Screen {
    data object Albums : Screen
    data class Grid(val bucketId: Long?, val title: String) : Screen
    data object HiddenAlbums : Screen
    data class HiddenGrid(val folder: String) : Screen
    data class Viewer(
        val bucketId: Long?,
        val index: Int,
        val title: String,
        val hidden: Boolean = false,
        val hiddenFolder: String? = null,
    ) : Screen
    data object Duplicates : Screen
}

private val requiredPermissions: Array<String>
    get() = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU ->
            arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
        Build.VERSION.SDK_INT <= Build.VERSION_CODES.P ->
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
        else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

class MainActivity : ComponentActivity() {
    companion object {
        const val EXTRA_OPEN_HIDDEN = "com.osmus.gallery.OPEN_HIDDEN"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFFE8663C),
                    background = Color(0xFF0B0B0C),
                    surface = Color(0xFF0B0B0C),
                    error = Color(0xFFD5443F),
                )
            ) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    AppRoot(openHiddenOnStart = intent?.getBooleanExtra(EXTRA_OPEN_HIDDEN, false) == true)
                }
            }
        }
    }
}

@Composable
private fun AppRoot(openHiddenOnStart: Boolean = false) {
    val context = LocalContext.current
    var granted by remember {
        mutableStateOf(requiredPermissions.all {
            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        })
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result -> granted = result.values.any { it } }

    LaunchedEffect(Unit) {
        if (!granted) permissionLauncher.launch(requiredPermissions)
    }

    if (!granted) {
        PermissionGate(onRequest = { permissionLauncher.launch(requiredPermissions) })
        return
    }
    Gallery(openHiddenOnStart = openHiddenOnStart)
}

@Composable
private fun PermissionGate(onRequest: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Serve l'accesso alle foto", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Text(
            "L'app legge foto e video dalla memoria del telefono. Niente esce dal " +
                    "dispositivo: non c'è rete, non c'è account, non c'è pubblicità.",
            fontSize = 13.sp,
            color = Color(0xFF9A9A97),
            modifier = Modifier.padding(top = 10.dp, bottom = 22.dp),
        )
        Button(onClick = onRequest) { Text("Consenti l'accesso") }
    }
}

@Composable
private fun Gallery(openHiddenOnStart: Boolean = false, vm: GalleryViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    val scan by vm.scan.collectAsState()
    val selection by vm.selection.collectAsState()
    var screen by remember { mutableStateOf<Screen>(if (openHiddenOnStart) Screen.HiddenAlbums else Screen.Albums) }
    val context = LocalContext.current
    val adminComponent = remember { ComponentName(context, DeviceAdminGuardReceiver::class.java) }
    val devicePolicyManager = remember { context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager }
    var uninstallGuardEnabled by remember { mutableStateOf(devicePolicyManager.isAdminActive(adminComponent)) }

    val adminLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { uninstallGuardEnabled = devicePolicyManager.isAdminActive(adminComponent) }

    fun launchAdminSetup() {
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
            putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Protegge i contenuti della Cassaforte da una disinstallazione accidentale. " +
                    "Android chiederà di disattivare questa protezione prima di rimuovere OsmusGallery."
            )
        }
        adminLauncher.launch(intent)
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { launchAdminSetup() }

    fun enableUninstallGuard() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            launchAdminSetup()
        }
    }

    fun disableUninstallGuard() {
        devicePolicyManager.removeActiveAdmin(adminComponent)
        uninstallGuardEnabled = false
    }

    LaunchedEffect(Unit) { vm.start() }

    val trashLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { vm.onDeletionFinished() }

    val hideLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        val success = result.resultCode == Activity.RESULT_OK
        vm.onHideFinished(success)
        if (success && !uninstallGuardEnabled) enableUninstallGuard()
    }

    fun trash(uris: List<android.net.Uri>) {
        val sender = vm.trashRequest(uris)
        if (sender != null) trashLauncher.launch(IntentSenderRequest.Builder(sender).build())
        else vm.onDeletionFinished()
    }

    fun hide(items: List<MediaItem>, targetFolder: String) {
        if (items.isEmpty()) return
        vm.prepareHide(items, targetFolder) { uris ->
            if (uris.isEmpty()) {
                vm.onHideFinished(false)
                return@prepareHide
            }
            val sender = vm.trashRequest(uris)
            if (sender != null) hideLauncher.launch(IntentSenderRequest.Builder(sender).build())
            else {
                vm.onHideFinished(true)
                if (!uninstallGuardEnabled) enableUninstallGuard()
            }
        }
    }

    if (state.loading && state.all.isEmpty() && state.hidden.isEmpty()) {
        Column(
            Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            CircularProgressIndicator()
            Text(
                "Lettura della libreria", fontSize = 13.sp, color = Color(0xFF9A9A97),
                modifier = Modifier.padding(top = 14.dp),
            )
        }
        return
    }

    Scaffold { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            when (val s = screen) {
                is Screen.Albums -> AlbumsScreen(
                    albums = state.albums,
                    columns = 3,
                    totalCount = state.all.size,
                    hiddenCount = state.hidden.size,
                    onOpenAlbum = { id ->
                        val name = state.albums.firstOrNull { it.bucketId == id }?.name ?: "Cartella"
                        vm.clearSelection()
                        screen = Screen.Grid(id, name)
                    },
                    onOpenAll = {
                        vm.clearSelection()
                        screen = Screen.Grid(null, "Tutti gli elementi")
                    },
                    onOpenDuplicates = {
                        vm.clearSelection()
                        screen = Screen.Duplicates
                    },
                    onOpenHidden = {
                        vm.clearSelection()
                        screen = Screen.HiddenAlbums
                    },
                    onHideAlbum = { album ->
                        hide(vm.itemsOf(album.bucketId), album.name)
                    },
                )

                is Screen.Grid -> PhotoGridScreen(
                    title = s.title,
                    items = vm.itemsOf(s.bucketId),
                    columns = state.columns,
                    squareThumbs = state.squareThumbs,
                    sort = state.sort,
                    selection = selection,
                    onBack = {
                        vm.clearSelection()
                        screen = Screen.Albums
                    },
                    onColumnsChange = vm::setColumns,
                    onSortChange = vm::setSort,
                    onToggleSquare = vm::toggleSquareThumbs,
                    onOpen = { index -> screen = Screen.Viewer(s.bucketId, index, s.title) },
                    onToggleSelect = vm::toggleSelection,
                    onHideSelected = {
                        hide(vm.selectedVisibleItems(), MediaRepository.DEFAULT_HIDDEN_FOLDER)
                    },
                )

                is Screen.HiddenAlbums -> HiddenAlbumsScreen(
                    albums = state.hiddenAlbums,
                    onOpen = { folder ->
                        vm.clearSelection()
                        screen = Screen.HiddenGrid(folder)
                    },
                    onBack = {
                        vm.clearSelection()
                        screen = Screen.Albums
                    },
                    onCreateFolder = vm::createHiddenFolder,
                    onRenameFolder = vm::renameHiddenFolder,
                    onRestoreFolder = { folder -> vm.restoreHidden(vm.itemsOf(null, true, folder)) },
                    onDeleteEmptyFolder = vm::deleteHiddenFolderIfEmpty,
                    uninstallGuardEnabled = uninstallGuardEnabled,
                    onEnableUninstallGuard = ::enableUninstallGuard,
                    onDisableUninstallGuard = ::disableUninstallGuard,
                )

                is Screen.HiddenGrid -> PhotoGridScreen(
                    title = s.folder,
                    items = vm.itemsOf(null, true, s.folder),
                    columns = state.columns,
                    squareThumbs = state.squareThumbs,
                    sort = state.sort,
                    selection = selection,
                    hiddenMode = true,
                    onBack = {
                        vm.clearSelection()
                        screen = Screen.HiddenAlbums
                    },
                    onColumnsChange = vm::setColumns,
                    onSortChange = vm::setSort,
                    onToggleSquare = vm::toggleSquareThumbs,
                    onOpen = { index ->
                        screen = Screen.Viewer(null, index, s.folder, hidden = true, hiddenFolder = s.folder)
                    },
                    onToggleSelect = vm::toggleSelection,
                    onRestoreSelected = { vm.restoreHidden(vm.selectedHiddenItems()) },
                )

                is Screen.Viewer -> {
                    val viewerItems = vm.itemsOf(s.bucketId, s.hidden, s.hiddenFolder)
                    ViewerScreen(
                        items = viewerItems,
                        startIndex = s.index,
                        onClose = {
                            screen = if (s.hidden) Screen.HiddenGrid(s.hiddenFolder ?: "Nascosti")
                            else Screen.Grid(s.bucketId, s.title)
                        },
                        onDelete = { item -> trash(listOf(item.uri)) },
                        onHide = { item -> hide(listOf(item), MediaRepository.DEFAULT_HIDDEN_FOLDER) },
                        onRestore = { item -> vm.restoreHidden(listOf(item)) },
                    )
                }

                is Screen.Duplicates -> DuplicatesScreen(
                    scan = scan,
                    selection = selection,
                    selectedBytes = vm.selectedBytes(),
                    onBack = {
                        vm.clearSelection()
                        screen = Screen.Albums
                    },
                    onStart = vm::startScan,
                    onCancel = vm::cancelScan,
                    onToggleSelect = vm::toggleSelection,
                    onSelectSuggested = vm::selectAllSuggested,
                    onClearSelection = vm::clearSelection,
                    onDeleteSelected = { trash(vm.selectedUris()) },
                )
            }
        }
    }
}
