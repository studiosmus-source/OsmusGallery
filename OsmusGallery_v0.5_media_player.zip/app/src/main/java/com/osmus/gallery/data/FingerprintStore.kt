package com.osmus.gallery.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/**
 * Cache delle impronte perceptive su SQLite di sistema.
 *
 * Niente Room: qui servono tre operazioni banali (leggi, scrivi in blocco,
 * pota) e Room porterebbe KSP, generazione di codice e un punto di rottura
 * in più a ogni aggiornamento di Kotlin. Con una tabella sola non serve.
 *
 * L'invalidazione è su (size, mtime): se uno dei due cambia, l'impronta
 * salvata non vale più e va ricalcolata.
 */
class FingerprintStore(context: Context) :
    SQLiteOpenHelper(context, "fingerprints.db", null, 1) {

    data class Row(val dhash: Long, val videoFp: LongArray?)

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE fp(
                uri TEXT PRIMARY KEY,
                size INTEGER NOT NULL,
                mtime INTEGER NOT NULL,
                dhash INTEGER NOT NULL,
                vfp TEXT
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS fp")
        onCreate(db)
    }

    /** Carica tutte le impronte ancora valide, indicizzate per uri. */
    fun loadValid(valid: Map<String, Pair<Long, Long>>): MutableMap<String, Row> {
        val out = HashMap<String, Row>(valid.size)
        readableDatabase.query(
            "fp", arrayOf("uri", "size", "mtime", "dhash", "vfp"),
            null, null, null, null, null
        ).use { c ->
            while (c.moveToNext()) {
                val uri = c.getString(0)
                val expected = valid[uri] ?: continue
                if (expected.first != c.getLong(1) || expected.second != c.getLong(2)) continue
                val vfp = if (c.isNull(4)) null else c.getString(4).toFingerprint()
                out[uri] = Row(c.getLong(3), vfp)
            }
        }
        return out
    }

    /** Scrittura in blocco: una transazione sola, non una per riga. */
    fun putAll(entries: List<Entry>) {
        if (entries.isEmpty()) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            val cv = ContentValues()
            for (e in entries) {
                cv.clear()
                cv.put("uri", e.uri)
                cv.put("size", e.size)
                cv.put("mtime", e.mtime)
                cv.put("dhash", e.dhash)
                cv.put("vfp", e.videoFp?.toStorage())
                db.insertWithOnConflict("fp", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    /** Rimuove le righe di file che non esistono più. */
    fun prune(liveUris: Set<String>) {
        val toDelete = ArrayList<String>()
        readableDatabase.query("fp", arrayOf("uri"), null, null, null, null, null).use { c ->
            while (c.moveToNext()) {
                val uri = c.getString(0)
                if (uri !in liveUris) toDelete += uri
            }
        }
        if (toDelete.isEmpty()) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            toDelete.forEach { db.delete("fp", "uri = ?", arrayOf(it)) }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    data class Entry(
        val uri: String,
        val size: Long,
        val mtime: Long,
        val dhash: Long,
        val videoFp: LongArray?,
    )
}

private fun LongArray.toStorage(): String = joinToString(",")

private fun String.toFingerprint(): LongArray? {
    if (isBlank()) return null
    return runCatching { split(",").map { it.trim().toLong() }.toLongArray() }.getOrNull()
}
