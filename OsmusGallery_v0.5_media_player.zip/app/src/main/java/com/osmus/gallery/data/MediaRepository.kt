package com.osmus.gallery.data

import android.content.ContentResolver
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.IntentSender
import android.database.Cursor
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Properties
import kotlin.math.absoluteValue

/**
 * Un elemento multimediale (foto, gif o video).
 *
 * Gli elementi normali arrivano da MediaStore; quelli nascosti vivono nella
 * cassaforte privata di OsmusGallery e hanno hidden=true.
 */
data class MediaItem(
    val id: Long,
    val uri: Uri,
    val name: String,
    val relativePath: String,
    val bucketId: Long,
    val bucketName: String,
    val size: Long,
    val dateTaken: Long,
    val dateModified: Long,
    val width: Int,
    val height: Int,
    val durationMs: Long,
    val mimeType: String,
    val hidden: Boolean = false,
    val localPath: String? = null,
) {
    val isVideo: Boolean get() = mimeType.startsWith("video")
    val isGif: Boolean get() = mimeType.equals("image/gif", ignoreCase = true)
    val pixels: Long get() = width.toLong() * height.toLong()

    /** Usata dall'euristica anti-duplicati: le cartelle "derivate" valgono meno. */
    val isDerivedFolder: Boolean
        get() {
            val p = (relativePath + bucketName).lowercase()
            return DERIVED_HINTS.any { p.contains(it) }
        }

    companion object {
        private val DERIVED_HINTS = listOf(
            "whatsapp", "telegram", "screenshot", "download", "messenger",
            "viber", "signal", "cache", ".thumbnails", "compress", "sent"
        )
    }
}

/** Una cartella/album così come lo mostra la schermata iniziale. */
data class Album(
    val bucketId: Long,
    val name: String,
    val count: Int,
    val cover: Uri,
    val newest: Long,
)

data class HiddenAlbum(
    val name: String,
    val count: Int,
    val cover: Uri?,
    val newest: Long,
)

data class HideResult(
    val originalUris: List<Uri>,
    val createdPaths: List<String>,
)

enum class SortOrder(val label: String) {
    DATE_DESC("Data, dalla più recente"),
    DATE_ASC("Data, dalla più vecchia"),
    NAME_ASC("Nome (A-Z)"),
    SIZE_DESC("Dimensione, dalla più grande"),
    TYPE("Tipo di file"),
    RANDOM("Casuale"),
}

class MediaRepository(private val context: Context) {

    private val resolver: ContentResolver get() = context.contentResolver
    private val vaultRoot: File
        get() = File(context.getExternalFilesDir(null) ?: context.filesDir, "OsmusHidden")

    /** Legge foto, GIF e video visibili da MediaStore. */
    suspend fun loadAll(sort: SortOrder = SortOrder.DATE_DESC): List<MediaItem> =
        withContext(Dispatchers.IO) {
            val out = ArrayList<MediaItem>(4096)
            out += query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, isVideo = false)
            out += query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, isVideo = true)
            sorted(out, sort)
        }

    /** Legge i file presenti nella cassaforte privata dell'app. */
    suspend fun loadHidden(sort: SortOrder = SortOrder.DATE_DESC): List<MediaItem> =
        withContext(Dispatchers.IO) {
            vaultRoot.mkdirs()
            val items = vaultRoot.listFiles().orEmpty()
                .filter { it.isDirectory }
                .flatMap { folder ->
                    folder.listFiles().orEmpty()
                        .filter { it.isFile && !it.name.endsWith(META_SUFFIX) }
                        .mapNotNull { file -> hiddenItem(file, folder.name) }
                }
            sorted(items, sort)
        }

    fun sorted(items: List<MediaItem>, sort: SortOrder): List<MediaItem> = when (sort) {
        SortOrder.DATE_DESC -> items.sortedByDescending { it.effectiveDate() }
        SortOrder.DATE_ASC -> items.sortedBy { it.effectiveDate() }
        SortOrder.NAME_ASC -> items.sortedBy { it.name.lowercase() }
        SortOrder.SIZE_DESC -> items.sortedByDescending { it.size }
        SortOrder.TYPE -> items.sortedWith(compareBy({ it.mimeType }, { -it.effectiveDate() }))
        SortOrder.RANDOM -> items.shuffled()
    }

    /** Raggruppa in album, con copertina = elemento più recente della cartella. */
    fun albums(items: List<MediaItem>): List<Album> =
        items.groupBy { it.bucketId }
            .map { (id, list) ->
                val newest = list.maxByOrNull { it.effectiveDate() } ?: list.first()
                Album(
                    bucketId = id,
                    name = newest.bucketName.ifBlank { "(senza nome)" },
                    count = list.size,
                    cover = newest.uri,
                    newest = newest.effectiveDate(),
                )
            }
            .sortedByDescending { it.newest }

    fun hiddenAlbums(items: List<MediaItem>): List<HiddenAlbum> {
        vaultRoot.mkdirs()
        val byFolder = items.groupBy { it.bucketName }
        return vaultRoot.listFiles().orEmpty()
            .filter { it.isDirectory }
            .map { folder ->
                val list = byFolder[folder.name].orEmpty()
                val newest = list.maxByOrNull { it.effectiveDate() }
                HiddenAlbum(
                    name = folder.name,
                    count = list.size,
                    cover = newest?.uri,
                    newest = newest?.effectiveDate() ?: folder.lastModified(),
                )
            }
            .sortedWith(compareByDescending<HiddenAlbum> { it.newest }.thenBy { it.name.lowercase() })
    }

    fun createHiddenFolder(name: String): Boolean {
        val safe = sanitizeFolder(name)
        if (safe.isBlank()) return false
        return File(vaultRoot, safe).mkdirs()
    }

    fun renameHiddenFolder(oldName: String, newName: String): Boolean {
        val safe = sanitizeFolder(newName)
        if (safe.isBlank()) return false
        val from = File(vaultRoot, oldName)
        val to = File(vaultRoot, safe)
        if (!from.exists() || to.exists()) return false
        return from.renameTo(to)
    }

    fun deleteHiddenFolderIfEmpty(name: String): Boolean {
        val dir = File(vaultRoot, name)
        return dir.isDirectory && dir.listFiles().orEmpty().isEmpty() && dir.delete()
    }

    /**
     * Copia gli elementi nella cassaforte. L'originale viene rimosso solo dopo
     * la conferma di sistema: per questo restituiamo gli URI e i path creati.
     */
    suspend fun prepareHide(items: List<MediaItem>, targetFolder: String): HideResult =
        withContext(Dispatchers.IO) {
            val folder = File(vaultRoot, sanitizeFolder(targetFolder).ifBlank { DEFAULT_HIDDEN_FOLDER })
            folder.mkdirs()
            val created = mutableListOf<String>()
            val originals = mutableListOf<Uri>()

            items.filter { !it.hidden }.forEach { item ->
                val target = uniqueFile(folder, item.name.ifBlank { "media_${item.id}" })
                resolver.openInputStream(item.uri)?.use { input ->
                    FileOutputStream(target).use { output -> input.copyTo(output) }
                } ?: return@forEach

                writeMeta(target, item)
                target.setLastModified(item.dateModified.takeIf { it > 0 } ?: System.currentTimeMillis())
                created += target.absolutePath
                originals += item.uri
            }
            HideResult(originals, created)
        }

    fun rollbackHide(createdPaths: List<String>) {
        createdPaths.forEach { p ->
            val f = File(p)
            runCatching { metaFile(f).delete() }
            runCatching { f.delete() }
            runCatching { f.parentFile?.takeIf { it.listFiles().orEmpty().isEmpty() }?.delete() }
        }
    }

    suspend fun restoreHidden(items: List<MediaItem>): Int = withContext(Dispatchers.IO) {
        var restored = 0
        items.filter { it.hidden }.forEach { item ->
            val file = item.localPath?.let(::File) ?: return@forEach
            if (!file.exists()) return@forEach
            val meta = readMeta(file)
            val originalName = meta.getProperty("originalName", item.name)
            val originalPath = meta.getProperty("originalRelativePath", "Pictures/OsmusGallery/")
            val mime = meta.getProperty("mimeType", item.mimeType)

            val ok = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                restoreModern(file, originalName, originalPath, mime)
            } else {
                restoreLegacy(file, originalName, mime)
            }
            if (ok) {
                metaFile(file).delete()
                file.delete()
                file.parentFile?.takeIf { it.listFiles().orEmpty().isEmpty() }?.delete()
                restored++
            }
        }
        restored
    }

    private fun restoreModern(file: File, name: String, relativePath: String, mime: String): Boolean {
        val base = if (mime.startsWith("video")) {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        } else {
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        }
        val safePath = relativePath.ifBlank {
            if (mime.startsWith("video")) "Movies/OsmusGallery/" else "Pictures/OsmusGallery/"
        }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, safePath)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = resolver.insert(base, values) ?: return false
        return runCatching {
            resolver.openOutputStream(uri, "w")!!.use { output ->
                FileInputStream(file).use { input -> input.copyTo(output) }
            }
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            true
        }.getOrElse {
            runCatching { resolver.delete(uri, null, null) }
            false
        }
    }

    @Suppress("DEPRECATION")
    private fun restoreLegacy(file: File, name: String, mime: String): Boolean {
        val base = if (mime.startsWith("video")) {
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
        } else {
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
        }
        val dir = File(base, "OsmusGallery").apply { mkdirs() }
        val target = uniqueFile(dir, name)
        return runCatching {
            FileInputStream(file).use { input ->
                FileOutputStream(target).use { output -> input.copyTo(output) }
            }
            MediaScannerConnection.scanFile(context, arrayOf(target.absolutePath), arrayOf(mime), null)
            true
        }.getOrDefault(false)
    }

    private fun hiddenItem(file: File, folderName: String): MediaItem? {
        val meta = readMeta(file)
        val mime = meta.getProperty("mimeType") ?: guessMime(file.name) ?: return null
        if (!(mime.startsWith("image/") || mime.startsWith("video/"))) return null
        if (mime.startsWith("image/") && mime != "image/gif" && !isImageExtension(file.extension)) {
            // lascia passare le immagini comuni; la MIME salvata resta la fonte principale
        }
        val modified = meta.getProperty("dateModified")?.toLongOrNull() ?: file.lastModified()
        val taken = meta.getProperty("dateTaken")?.toLongOrNull() ?: modified
        return MediaItem(
            id = -stableId(file.absolutePath),
            uri = Uri.fromFile(file),
            name = meta.getProperty("originalName", file.name),
            relativePath = meta.getProperty("originalRelativePath", ""),
            bucketId = -stableId("folder:$folderName"),
            bucketName = folderName,
            size = file.length(),
            dateTaken = taken,
            dateModified = modified,
            width = meta.getProperty("width")?.toIntOrNull() ?: 0,
            height = meta.getProperty("height")?.toIntOrNull() ?: 0,
            durationMs = meta.getProperty("durationMs")?.toLongOrNull() ?: 0L,
            mimeType = mime,
            hidden = true,
            localPath = file.absolutePath,
        )
    }

    private fun writeMeta(file: File, item: MediaItem) {
        val p = Properties().apply {
            setProperty("originalName", item.name)
            setProperty("originalRelativePath", item.relativePath)
            setProperty("mimeType", item.mimeType)
            setProperty("dateTaken", item.dateTaken.toString())
            setProperty("dateModified", item.dateModified.toString())
            setProperty("width", item.width.toString())
            setProperty("height", item.height.toString())
            setProperty("durationMs", item.durationMs.toString())
        }
        FileOutputStream(metaFile(file)).use { p.store(it, "OsmusGallery hidden media metadata") }
    }

    private fun readMeta(file: File): Properties = Properties().apply {
        val meta = metaFile(file)
        if (meta.exists()) runCatching { FileInputStream(meta).use { load(it) } }
    }

    private fun metaFile(file: File) = File(file.parentFile, file.name + META_SUFFIX)

    private fun sanitizeFolder(name: String): String = name
        .trim()
        .replace(Regex("[\\\\/:*?\"<>|]"), "_")
        .replace(Regex("^\\.+"), "")
        .take(80)

    private fun uniqueFile(dir: File, requestedName: String): File {
        val safe = requestedName.replace(Regex("[\\\\/:*?\"<>|]"), "_")
        var candidate = File(dir, safe)
        if (!candidate.exists()) return candidate
        val dot = safe.lastIndexOf('.')
        val stem = if (dot > 0) safe.substring(0, dot) else safe
        val ext = if (dot > 0) safe.substring(dot) else ""
        var n = 2
        while (candidate.exists()) {
            candidate = File(dir, "$stem ($n)$ext")
            n++
        }
        return candidate
    }

    private fun guessMime(name: String): String? = when (name.substringAfterLast('.', "").lowercase()) {
        "jpg", "jpeg" -> "image/jpeg"
        "png" -> "image/png"
        "webp" -> "image/webp"
        "heic", "heif" -> "image/heic"
        "gif" -> "image/gif"
        "mp4", "m4v" -> "video/mp4"
        "mov" -> "video/quicktime"
        "mkv" -> "video/x-matroska"
        "webm" -> "video/webm"
        "3gp" -> "video/3gpp"
        else -> null
    }

    private fun isImageExtension(ext: String): Boolean =
        ext.lowercase() in setOf("jpg", "jpeg", "png", "webp", "heic", "heif", "gif")

    private fun stableId(s: String): Long {
        var hash = 1125899906842597L
        s.forEach { ch -> hash = 31L * hash + ch.code }
        return hash.absoluteValue.coerceAtLeast(1L)
    }

    private fun query(base: Uri, isVideo: Boolean): List<MediaItem> {
        val projection = buildList {
            add(MediaStore.MediaColumns._ID)
            add(MediaStore.MediaColumns.DISPLAY_NAME)
            add(MediaStore.MediaColumns.BUCKET_ID)
            add(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME)
            add(MediaStore.MediaColumns.SIZE)
            add(MediaStore.MediaColumns.DATE_MODIFIED)
            add(MediaStore.MediaColumns.DATE_TAKEN)
            add(MediaStore.MediaColumns.WIDTH)
            add(MediaStore.MediaColumns.HEIGHT)
            add(MediaStore.MediaColumns.MIME_TYPE)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) add(MediaStore.MediaColumns.RELATIVE_PATH)
            if (isVideo) add(MediaStore.Video.Media.DURATION)
        }.toTypedArray()

        val out = ArrayList<MediaItem>()
        val cursor: Cursor = resolver.query(
            base, projection, null, null,
            "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"
        ) ?: return out

        cursor.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val iBucket = c.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_ID)
            val iBucketName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME)
            val iSize = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            val iMod = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)
            val iTaken = c.getColumnIndex(MediaStore.MediaColumns.DATE_TAKEN)
            val iW = c.getColumnIndex(MediaStore.MediaColumns.WIDTH)
            val iH = c.getColumnIndex(MediaStore.MediaColumns.HEIGHT)
            val iMime = c.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)
            val iPath = c.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)
            val iDur = if (isVideo) c.getColumnIndex(MediaStore.Video.Media.DURATION) else -1

            while (c.moveToNext()) {
                val id = c.getLong(iId)
                out += MediaItem(
                    id = id,
                    uri = ContentUris.withAppendedId(base, id),
                    name = c.getStringOrEmpty(iName),
                    relativePath = if (iPath >= 0) c.getStringOrEmpty(iPath) else "",
                    bucketId = c.getLong(iBucket),
                    bucketName = c.getStringOrEmpty(iBucketName),
                    size = c.getLong(iSize),
                    dateTaken = if (iTaken >= 0 && !c.isNull(iTaken)) c.getLong(iTaken) else 0L,
                    dateModified = c.getLong(iMod) * 1000L,
                    width = if (iW >= 0) c.getInt(iW) else 0,
                    height = if (iH >= 0) c.getInt(iH) else 0,
                    durationMs = if (iDur >= 0 && !c.isNull(iDur)) c.getLong(iDur) else 0L,
                    mimeType = c.getStringOrEmpty(iMime).ifBlank { if (isVideo) "video/*" else "image/*" },
                )
            }
        }
        return out
    }

    /** Sposta nel cestino di sistema (recuperabile 30 giorni) su API 30+. */
    fun requestTrash(uris: List<Uri>): IntentSender? {
        if (uris.isEmpty()) return null
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            MediaStore.createTrashRequest(resolver, uris, true).intentSender
        } else {
            uris.forEach { runCatching { resolver.delete(it, null, null) } }
            null
        }
    }

    /** Cancellazione definitiva, sempre con conferma di sistema su API 30+. */
    fun requestDelete(uris: List<Uri>): IntentSender? {
        if (uris.isEmpty()) return null
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            MediaStore.createDeleteRequest(resolver, uris).intentSender
        } else {
            uris.forEach { runCatching { resolver.delete(it, null, null) } }
            null
        }
    }

    companion object {
        private const val META_SUFFIX = ".osmusmeta"
        const val DEFAULT_HIDDEN_FOLDER = "Nascosti"
    }
}

/** DATE_TAKEN è il dato giusto quando c'è; DATE_MODIFIED è il ripiego. */
fun MediaItem.effectiveDate(): Long = if (dateTaken > 0) dateTaken else dateModified

private fun Cursor.getStringOrEmpty(index: Int): String =
    if (index >= 0 && !isNull(index)) getString(index) ?: "" else ""
