package com.osmus.gallery.dedupe

import android.content.Context
import com.osmus.gallery.data.FingerprintStore
import com.osmus.gallery.data.MediaItem
import com.osmus.gallery.data.effectiveDate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicInteger

enum class GroupKind(val label: String) {
    EXACT("Copie identiche"),
    SIMILAR_IMAGE("Immagini simili"),
    SIMILAR_VIDEO("Video simili"),
}

data class DuplicateGroup(
    val kind: GroupKind,
    val items: List<MediaItem>,
    /** Indice in [items] dell'elemento da conservare secondo l'euristica. */
    val keepIndex: Int,
) {
    val reclaimableBytes: Long
        get() = items.filterIndexed { i, _ -> i != keepIndex }.sumOf { it.size }
}

data class ScanProgress(val done: Int, val total: Int, val phase: String)

class DuplicateFinder(private val context: Context) {

    /** Soglie. Alzarle trova più gruppi ma più falsi positivi. */
    var imageThreshold: Int = 10        // Hamming su 64 bit
    var videoFrameThreshold: Int = 8    // Hamming per singolo fotogramma
    var videoMinMatches: Int = 5        // su 7 posizioni
    var videoDurationToleranceMs: Long = 2_000

    private val store = FingerprintStore(context)

    suspend fun scan(
        items: List<MediaItem>,
        onProgress: (ScanProgress) -> Unit,
    ): List<DuplicateGroup> = withContext(Dispatchers.Default) {
        val resolver = context.contentResolver

        // ---------- Stadio 1: duplicati byte-identici ----------
        onProgress(ScanProgress(0, items.size, "Confronto dimensioni"))
        val exactGroups = ArrayList<DuplicateGroup>()
        val consumed = HashSet<Long>()

        val bySize = items.filter { it.size > 0 }.groupBy { it.size }
        val sizeCandidates = bySize.values.filter { it.size > 1 }.flatten()
        val hashDone = AtomicInteger(0)

        val hashed = parallelMap(sizeCandidates) { item ->
            val h = Hashing.contentHash(resolver, item.uri, item.size)
            val n = hashDone.incrementAndGet()
            if (n % 25 == 0) {
                onProgress(ScanProgress(n, sizeCandidates.size, "Verifica copie identiche"))
            }
            if (h == null) null else (item to "${item.size}:$h")
        }.filterNotNull()

        hashed.groupBy { it.second }.values.forEach { bucket ->
            if (bucket.size > 1) {
                val group = bucket.map { it.first }
                exactGroups += DuplicateGroup(
                    kind = GroupKind.EXACT,
                    items = group,
                    keepIndex = chooseKeeper(group),
                )
                group.forEach { consumed += it.id }
            }
        }

        // ---------- Impronte perceptive, con cache ----------
        val remaining = items.filter { it.id !in consumed }
        val validity = remaining.associate {
            it.uri.toString() to (it.size to it.dateModified)
        }
        val cached = store.loadValid(validity)

        val toCompute = remaining.filter { it.uri.toString() !in cached }
        onProgress(ScanProgress(0, toCompute.size, "Calcolo impronte"))

        val computeDone = AtomicInteger(0)
        val fresh = parallelMap(toCompute) { item ->
            val entry = if (item.isVideo || item.isGif) {
                val fp = Hashing.videoFingerprint(resolver, item.uri)
                if (fp == null) null
                else FingerprintStore.Entry(
                    item.uri.toString(), item.size, item.dateModified, fp[0], fp
                )
            } else {
                val bmp = Hashing.decodeThumb(resolver, item.uri)
                if (bmp == null) null
                else {
                    val h = Hashing.dHash(bmp)
                    bmp.recycle()
                    FingerprintStore.Entry(
                        item.uri.toString(), item.size, item.dateModified, h, null
                    )
                }
            }
            val n = computeDone.incrementAndGet()
            if (n % 20 == 0) {
                onProgress(ScanProgress(n, toCompute.size, "Calcolo impronte"))
            }
            entry
        }.filterNotNull()

        store.putAll(fresh)
        fresh.forEach { cached[it.uri] = FingerprintStore.Row(it.dhash, it.videoFp) }

        // ---------- Stadio 2: immagini simili, indice LSH ----------
        onProgress(ScanProgress(0, 0, "Ricerca immagini simili"))
        val images = remaining.filter { !it.isVideo && !it.isGif }
            .mapNotNull { item ->
                cached[item.uri.toString()]?.let { item to it.dhash }
            }
        val imageGroups = groupImages(images)
        imageGroups.forEach { g -> g.items.forEach { consumed += it.id } }

        // ---------- Stadio 3: video e GIF ----------
        onProgress(ScanProgress(0, 0, "Ricerca video simili"))
        val videos = remaining.filter { (it.isVideo || it.isGif) && it.id !in consumed }
            .mapNotNull { item ->
                cached[item.uri.toString()]?.videoFp?.let { item to it }
            }
        val videoGroups = groupVideos(videos)

        store.prune(items.map { it.uri.toString() }.toSet())

        (exactGroups + imageGroups + videoGroups)
            .sortedByDescending { it.reclaimableBytes }
    }

    // ------------------------------------------------------------------
    // Raggruppamento immagini con LSH a bande.
    //
    // Il confronto di tutte le coppie è O(n^2): su 30.000 foto sono 450
    // milioni di confronti. Spezzando l'hash in 8 bande da 8 bit e
    // confrontando solo chi collide in almeno una banda, si scende di
    // ordini di grandezza. Due hash a distanza <= 10 su 64 bit hanno
    // altissima probabilità di condividere almeno una banda intatta.
    // ------------------------------------------------------------------
    private fun groupImages(entries: List<Pair<MediaItem, Long>>): List<DuplicateGroup> {
        if (entries.size < 2) return emptyList()

        val bands = 8
        val buckets = HashMap<Int, MutableList<Int>>()
        for (i in entries.indices) {
            val h = entries[i].second
            for (b in 0 until bands) {
                val band = ((h ushr (b * 8)) and 0xFF).toInt()
                val key = b * 256 + band
                buckets.getOrPut(key) { ArrayList() }.add(i)
            }
        }

        val uf = UnionFind(entries.size)
        val seenPairs = HashSet<Long>()
        for (bucket in buckets.values) {
            if (bucket.size < 2 || bucket.size > 400) continue  // bucket degeneri: salta
            for (x in bucket.indices) {
                for (y in x + 1 until bucket.size) {
                    val i = bucket[x]
                    val j = bucket[y]
                    val key = pairKey(i, j)
                    if (!seenPairs.add(key)) continue
                    if (Hashing.hamming(entries[i].second, entries[j].second) <= imageThreshold) {
                        uf.union(i, j)
                    }
                }
            }
        }
        return uf.groups()
            .filter { it.size > 1 }
            .map { idx ->
                val group = idx.map { entries[it].first }
                DuplicateGroup(GroupKind.SIMILAR_IMAGE, group, chooseKeeper(group))
            }
    }

    // ------------------------------------------------------------------
    // Video: pre-filtro sulla durata prima di qualsiasi confronto di
    // impronte. Due video simili hanno durata quasi identica, e questo
    // taglia la quasi totalità delle coppie a costo zero.
    // ------------------------------------------------------------------
    private fun groupVideos(entries: List<Pair<MediaItem, LongArray>>): List<DuplicateGroup> {
        if (entries.size < 2) return emptyList()

        val bucketMs = videoDurationToleranceMs
        val byDuration = HashMap<Long, MutableList<Int>>()
        for (i in entries.indices) {
            val slot = entries[i].first.durationMs / bucketMs
            byDuration.getOrPut(slot) { ArrayList() }.add(i)
        }

        val uf = UnionFind(entries.size)
        for ((slot, list) in byDuration) {
            // Confronta con lo slot stesso e con il successivo, per non
            // perdere le coppie che cadono a cavallo di un confine.
            val candidates = list + (byDuration[slot + 1] ?: emptyList())
            for (x in candidates.indices) {
                for (y in x + 1 until candidates.size) {
                    val i = candidates[x]
                    val j = candidates[y]
                    if (i == j) continue
                    val matches = Hashing.fingerprintMatches(
                        entries[i].second, entries[j].second, videoFrameThreshold
                    )
                    if (matches >= videoMinMatches) uf.union(i, j)
                }
            }
        }
        return uf.groups()
            .filter { it.size > 1 }
            .map { idx ->
                val group = idx.map { entries[it].first }
                DuplicateGroup(GroupKind.SIMILAR_VIDEO, group, chooseKeeper(group))
            }
    }

    // ------------------------------------------------------------------
    // Euristica: quale copia tenere.
    //
    // Ordine deliberato. La risoluzione viene prima della dimensione
    // perché un file più grande può essere solo meno compresso; conta
    // l'informazione, non i byte. La cartella derivata pesa molto perché
    // un file in WhatsApp è quasi sempre la copia, non l'originale.
    // ------------------------------------------------------------------
    fun chooseKeeper(group: List<MediaItem>): Int {
        var bestIndex = 0
        var bestScore = Long.MIN_VALUE
        for (i in group.indices) {
            val it = group[i]
            var score = 0L
            score += it.pixels * 4
            score += it.size / 1024
            if (it.isDerivedFolder) score -= 5_000_000
            if (it.dateTaken > 0) score += 1_000_000        // ha EXIF: è l'originale
            if (it.name.contains("(1)") || it.name.contains("copy", true)) score -= 2_000_000
            // A parità di tutto, il più vecchio vince.
            score -= it.effectiveDate() / 100_000
            if (score > bestScore) {
                bestScore = score
                bestIndex = i
            }
        }
        return bestIndex
    }

    private fun pairKey(a: Int, b: Int): Long {
        val lo = minOf(a, b).toLong()
        val hi = maxOf(a, b).toLong()
        return (hi shl 32) or lo
    }

    /** Parallelismo pari ai core, senza thread pool propri. */
    private suspend fun <T, R> parallelMap(
        input: List<T>,
        transform: suspend (T) -> R,
    ): List<R> = coroutineScope {
        if (input.isEmpty()) return@coroutineScope emptyList()
        val workers = Runtime.getRuntime().availableProcessors().coerceIn(2, 6)
        val chunks = input.chunked((input.size + workers - 1) / workers)
        chunks.map { chunk ->
            async(Dispatchers.IO) { chunk.map { transform(it) } }
        }.flatMap { it.await() }
    }
}

/** Union-find con compressione di cammino: i gruppi transitivi sono gratis. */
private class UnionFind(size: Int) {
    private val parent = IntArray(size) { it }

    fun find(x: Int): Int {
        var root = x
        while (parent[root] != root) root = parent[root]
        var cur = x
        while (parent[cur] != root) {
            val next = parent[cur]
            parent[cur] = root
            cur = next
        }
        return root
    }

    fun union(a: Int, b: Int) {
        val ra = find(a)
        val rb = find(b)
        if (ra != rb) parent[rb] = ra
    }

    fun groups(): List<List<Int>> {
        val map = HashMap<Int, MutableList<Int>>()
        for (i in parent.indices) {
            map.getOrPut(find(i)) { ArrayList() }.add(i)
        }
        return map.values.toList()
    }
}
