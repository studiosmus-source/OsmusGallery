package com.osmus.gallery.dedupe

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import java.io.InputStream
import java.security.MessageDigest

/**
 * Impronte perceptive.
 *
 * Scelta: dHash a 64 bit invece di pHash/DCT. Il dHash confronta la luminanza
 * di pixel adiacenti, quindi è invariante a ricompressione JPEG, a
 * ridimensionamento e a variazioni uniformi di luminosità: esattamente i
 * casi che generano duplicati veri (rinvii WhatsApp, screenshot di foto,
 * export a qualità diversa). Il pHash aggiunge robustezza alle rotazioni,
 * che però nei duplicati reali sono rare, e costa una DCT per immagine.
 */
object Hashing {

    const val SAMPLE = 9          // 9x8 -> 72 pixel -> 64 confronti orizzontali
    const val ROWS = 8
    private const val TARGET_DECODE_PX = 64

    /** Gradiente orizzontale su griglia 9x8 in scala di grigi. */
    fun dHash(bitmap: Bitmap): Long {
        val small = Bitmap.createScaledBitmap(bitmap, SAMPLE, ROWS, true)
        val pixels = IntArray(SAMPLE * ROWS)
        small.getPixels(pixels, 0, SAMPLE, 0, 0, SAMPLE, ROWS)
        if (small !== bitmap) small.recycle()

        var hash = 0L
        var bit = 0
        for (y in 0 until ROWS) {
            for (x in 0 until SAMPLE - 1) {
                val left = luma(pixels[y * SAMPLE + x])
                val right = luma(pixels[y * SAMPLE + x + 1])
                if (left > right) hash = hash or (1L shl bit)
                bit++
            }
        }
        return hash
    }

    private fun luma(argb: Int): Int {
        val r = (argb shr 16) and 0xFF
        val g = (argb shr 8) and 0xFF
        val b = argb and 0xFF
        // Coefficienti Rec. 601, in interi per evitare float nel ciclo caldo.
        return (r * 299 + g * 587 + b * 114) / 1000
    }

    fun hamming(a: Long, b: Long): Int = java.lang.Long.bitCount(a xor b)

    /**
     * Decodifica un'immagine a circa 64 px sul lato lungo.
     *
     * Due passaggi: prima solo i bounds, poi inSampleSize. Decodificare
     * l'immagine intera per poi scalarla a 9x8 significa allocare 50 MB per
     * una foto da 48 megapixel e finire in OutOfMemory dopo poche decine
     * di file.
     */
    fun decodeThumb(resolver: ContentResolver, uri: Uri): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        openStream(resolver, uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        val longest = maxOf(bounds.outWidth, bounds.outHeight)
        var sample = 1
        while (longest / (sample * 2) >= TARGET_DECODE_PX) sample *= 2

        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        return openStream(resolver, uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    }

    /**
     * Impronta di un video o di una GIF: dHash di 7 fotogrammi campionati
     * a percentuali fisse della durata.
     *
     * Le percentuali evitano l'inizio e la fine assoluti, che spesso sono
     * neri o sono titoli di testa, e sono deterministiche: due copie dello
     * stesso video campionano gli stessi istanti anche a risoluzioni
     * diverse.
     */
    val FRAME_POSITIONS = floatArrayOf(0.10f, 0.25f, 0.40f, 0.50f, 0.60f, 0.75f, 0.90f)

    fun videoFingerprint(resolver: ContentResolver, uri: Uri): LongArray? {
        val retriever = MediaMetadataRetriever()
        return try {
            resolver.openFileDescriptor(uri, "r")?.use { pfd ->
                retriever.setDataSource(pfd.fileDescriptor)
            } ?: return null

            val durationMs = retriever
                .extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: return null
            if (durationMs <= 0) return null

            val out = LongArray(FRAME_POSITIONS.size)
            for (i in FRAME_POSITIONS.indices) {
                val us = (durationMs * FRAME_POSITIONS[i] * 1000L).toLong()
                val frame = retriever.getFrameAtTime(
                    us, MediaMetadataRetriever.OPTION_CLOSEST_SYNC
                ) ?: return null
                out[i] = dHash(frame)
                frame.recycle()
            }
            out
        } catch (_: Throwable) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }

    /**
     * Quante posizioni dell'impronta coincidono entro la soglia.
     * Due video sono considerati simili con almeno 5 corrispondenze su 7.
     */
    fun fingerprintMatches(a: LongArray, b: LongArray, perFrameThreshold: Int): Int {
        val n = minOf(a.size, b.size)
        var matches = 0
        for (i in 0 until n) if (hamming(a[i], b[i]) <= perFrameThreshold) matches++
        return matches
    }

    /**
     * Hash di contenuto per i duplicati byte-identici.
     * Sotto gli 8 MB legge tutto; sopra, testa e coda: su file grandi
     * la probabilità di collisione a parità di dimensione esatta è
     * trascurabile e il risparmio di I/O è enorme.
     */
    fun contentHash(resolver: ContentResolver, uri: Uri, size: Long): String? {
        val digest = MessageDigest.getInstance("MD5")
        val full = size <= 8L * 1024 * 1024
        return try {
            openStream(resolver, uri)?.use { input ->
                val buf = ByteArray(64 * 1024)
                if (full) {
                    while (true) {
                        val read = input.read(buf)
                        if (read <= 0) break
                        digest.update(buf, 0, read)
                    }
                } else {
                    var read = input.read(buf)
                    if (read > 0) digest.update(buf, 0, read)
                    val skipTo = size - 64 * 1024
                    var skipped = read.toLong()
                    while (skipped < skipTo) {
                        val s = input.skip(skipTo - skipped)
                        if (s <= 0) break
                        skipped += s
                    }
                    read = input.read(buf)
                    if (read > 0) digest.update(buf, 0, read)
                }
            } ?: return null
            digest.digest().joinToString("") { "%02x".format(it) }
        } catch (_: Throwable) {
            null
        }
    }

    private fun openStream(resolver: ContentResolver, uri: Uri): InputStream? =
        runCatching { resolver.openInputStream(uri) }.getOrNull()
}
