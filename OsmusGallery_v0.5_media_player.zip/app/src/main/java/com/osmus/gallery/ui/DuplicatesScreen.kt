package com.osmus.gallery.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.osmus.gallery.data.MediaItem
import com.osmus.gallery.dedupe.DuplicateGroup

@Composable
fun DuplicatesScreen(
    scan: ScanState,
    selection: Set<Long>,
    onBack: () -> Unit,
    onStart: () -> Unit,
    onCancel: () -> Unit,
    onToggleSelect: (Long) -> Unit,
    onSelectSuggested: () -> Unit,
    onClearSelection: () -> Unit,
    onDeleteSelected: () -> Unit,
    selectedBytes: Long,
) {
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Indietro")
            }
            Column(Modifier.weight(1f)) {
                Text("Duplicati", fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    when {
                        scan.running -> scan.progress?.phase ?: "Analisi in corso"
                        scan.completed -> "${scan.groups.size} gruppi · " +
                                "${scan.reclaimableBytes.formatBytes()} recuperabili"
                        else -> "Nessuna analisi eseguita"
                    },
                    fontSize = 12.sp,
                    color = Color(0xFF9A9A97),
                )
            }
        }

        when {
            scan.running -> ScanningState(scan, onCancel)
            !scan.completed -> IdleState(onStart)
            scan.groups.isEmpty() -> EmptyResult(onStart)
            else -> {
                ActionBar(
                    selectionCount = selection.size,
                    selectedBytes = selectedBytes,
                    onSelectSuggested = onSelectSuggested,
                    onClearSelection = onClearSelection,
                    onDeleteSelected = onDeleteSelected,
                )
                LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(
                        bottom = 24.dp
                    ),
                ) {
                    items(scan.groups.size) { index ->
                        GroupRow(
                            group = scan.groups[index],
                            selection = selection,
                            onToggleSelect = onToggleSelect,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun IdleState(onStart: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            "Cerca copie e file simili",
            fontSize = 20.sp,
            fontWeight = FontWeight.SemiBold,
        )
        Text(
            "L'analisi confronta prima le dimensioni, poi il contenuto visivo di foto, " +
                    "GIF e video. La prima volta richiede qualche minuto; dalle volte " +
                    "successive analizza solo i file nuovi.",
            fontSize = 13.sp,
            color = Color(0xFF9A9A97),
            modifier = Modifier.padding(top = 10.dp, bottom = 22.dp),
        )
        Button(onClick = onStart) { Text("Avvia analisi") }
    }
}

@Composable
private fun ScanningState(scan: ScanState, onCancel: () -> Unit) {
    val p = scan.progress
    Column(
        Modifier
            .fillMaxSize()
            .padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        if (p != null && p.total > 0) {
            LinearProgressIndicator(
                progress = { (p.done.toFloat() / p.total).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth(),
            )
            Text(
                "${p.done} di ${p.total}",
                fontSize = 12.sp,
                color = Color(0xFF9A9A97),
                modifier = Modifier.padding(top = 10.dp),
            )
        } else {
            CircularProgressIndicator()
        }
        Text(
            p?.phase ?: "Analisi in corso",
            fontSize = 14.sp,
            modifier = Modifier.padding(top = 14.dp, bottom = 20.dp),
        )
        OutlinedButton(onClick = onCancel) { Text("Interrompi") }
    }
}

@Composable
private fun EmptyResult(onStart: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Nessun duplicato trovato", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Text(
            "Se pensi che ce ne siano, aumenta la tolleranza nel motore di confronto.",
            fontSize = 13.sp,
            color = Color(0xFF9A9A97),
            modifier = Modifier.padding(top = 8.dp, bottom = 20.dp),
        )
        OutlinedButton(onClick = onStart) { Text("Rianalizza") }
    }
}

@Composable
private fun ActionBar(
    selectionCount: Int,
    selectedBytes: Long,
    onSelectSuggested: () -> Unit,
    onClearSelection: () -> Unit,
    onDeleteSelected: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(Color(0xFF151618))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        if (selectionCount == 0) {
            OutlinedButton(onClick = onSelectSuggested, modifier = Modifier.weight(1f)) {
                Text("Seleziona le copie", fontSize = 13.sp)
            }
        } else {
            OutlinedButton(onClick = onClearSelection) { Text("Annulla", fontSize = 13.sp) }
            Button(onClick = onDeleteSelected, modifier = Modifier.weight(1f)) {
                Icon(
                    Icons.Filled.Delete,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                )
                Text(
                    "  Sposta nel cestino $selectionCount · ${selectedBytes.formatBytes()}",
                    fontSize = 13.sp,
                )
            }
        }
    }
}

@Composable
private fun GroupRow(
    group: DuplicateGroup,
    selection: Set<Long>,
    onToggleSelect: (Long) -> Unit,
) {
    Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                group.kind.label,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f),
            )
            Text(
                "${group.items.size} file · ${group.reclaimableBytes.formatBytes()}",
                fontSize = 11.sp,
                color = Color(0xFF9A9A97),
            )
        }
        LazyRow(
            Modifier.padding(top = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            items(group.items.size) { i ->
                val item = group.items[i]
                DuplicateThumb(
                    item = item,
                    isKeeper = i == group.keepIndex,
                    selected = item.id in selection,
                    onClick = { onToggleSelect(item.id) },
                )
            }
        }
    }
}

@Composable
private fun DuplicateThumb(
    item: MediaItem,
    isKeeper: Boolean,
    selected: Boolean,
    onClick: () -> Unit,
) {
    Column(Modifier.size(width = 104.dp, height = 152.dp)) {
        Box(
            Modifier
                .size(104.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF1A1B1D))
                .clickable(onClick = onClick)
        ) {
            AsyncImage(
                model = item.uri,
                contentDescription = item.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
            if (selected) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.error.copy(alpha = 0.42f))
                )
                Icon(
                    Icons.Filled.CheckCircle,
                    contentDescription = "Da eliminare",
                    tint = Color.White,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(4.dp)
                        .size(18.dp),
                )
            }
            if (isKeeper) {
                Text(
                    "DA TENERE",
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(4.dp)
                        .background(Color(0xFF2E7D4F), RoundedCornerShape(3.dp))
                        .padding(horizontal = 5.dp, vertical = 2.dp),
                )
            }
        }
        Text(
            item.name,
            fontSize = 10.sp,
            maxLines = 2,
            color = Color(0xFFCECECC),
            modifier = Modifier.padding(top = 4.dp),
        )
        Text(
            "${item.width}x${item.height} · ${item.size.formatBytes()}",
            fontSize = 9.sp,
            color = Color(0xFF8A8A88),
        )
        if (item.bucketName.isNotBlank()) {
            Text(
                item.bucketName,
                fontSize = 9.sp,
                maxLines = 1,
                color = Color(0xFF6F6F6D),
            )
        }
    }
}
