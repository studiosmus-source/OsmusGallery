package com.osmus.gallery.ui

import android.app.Application
import android.database.ContentObserver
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.osmus.gallery.data.Album
import com.osmus.gallery.data.HiddenAlbum
import com.osmus.gallery.data.MediaItem
import com.osmus.gallery.data.MediaRepository
import com.osmus.gallery.data.SortOrder
import com.osmus.gallery.dedupe.DuplicateFinder
import com.osmus.gallery.dedupe.DuplicateGroup
import com.osmus.gallery.dedupe.ScanProgress
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class GalleryState(
    val loading: Boolean = true,
    val all: List<MediaItem> = emptyList(),
    val hidden: List<MediaItem> = emptyList(),
    val albums: List<Album> = emptyList(),
    val hiddenAlbums: List<HiddenAlbum> = emptyList(),
    val sort: SortOrder = SortOrder.DATE_DESC,
    val columns: Int = 3,
    val squareThumbs: Boolean = true,
)

data class ScanState(
    val running: Boolean = false,
    val progress: ScanProgress? = null,
    val groups: List<DuplicateGroup> = emptyList(),
    val completed: Boolean = false,
) {
    val reclaimableBytes: Long get() = groups.sumOf { it.reclaimableBytes }
}

class GalleryViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = MediaRepository(app)
    private val finder = DuplicateFinder(app)

    private val _state = MutableStateFlow(GalleryState())
    val state: StateFlow<GalleryState> = _state.asStateFlow()

    private val _scan = MutableStateFlow(ScanState())
    val scan: StateFlow<ScanState> = _scan.asStateFlow()

    private val _selection = MutableStateFlow<Set<Long>>(emptySet())
    val selection: StateFlow<Set<Long>> = _selection.asStateFlow()

    private var scanJob: Job? = null
    private var observer: ContentObserver? = null
    private var pendingHiddenPaths: List<String> = emptyList()

    fun start() {
        if (observer == null) registerObserver()
        reload()
    }

    fun reload() {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true)
            val visible = repo.loadAll(_state.value.sort)
            val hidden = repo.loadHidden(_state.value.sort)
            _state.value = _state.value.copy(
                loading = false,
                all = visible,
                hidden = hidden,
                albums = repo.albums(visible),
                hiddenAlbums = repo.hiddenAlbums(hidden),
            )
        }
    }

    fun setSort(sort: SortOrder) {
        _state.value = _state.value.copy(
            sort = sort,
            all = repo.sorted(_state.value.all, sort),
            hidden = repo.sorted(_state.value.hidden, sort),
        )
    }

    fun setColumns(columns: Int) {
        _state.value = _state.value.copy(columns = columns.coerceIn(2, 7))
    }

    fun toggleSquareThumbs() {
        _state.value = _state.value.copy(squareThumbs = !_state.value.squareThumbs)
    }

    fun itemsOf(bucketId: Long?, hidden: Boolean = false, hiddenFolder: String? = null): List<MediaItem> {
        val source = if (hidden) _state.value.hidden else _state.value.all
        return when {
            hidden && hiddenFolder != null -> source.filter { it.bucketName == hiddenFolder }
            bucketId == null -> source
            else -> source.filter { it.bucketId == bucketId }
        }
    }

    fun toggleSelection(id: Long) {
        val cur = _selection.value
        _selection.value = if (id in cur) cur - id else cur + id
    }

    fun clearSelection() {
        _selection.value = emptySet()
    }

    fun selectAllSuggested() {
        val ids = _scan.value.groups.flatMap { g ->
            g.items.filterIndexed { i, _ -> i != g.keepIndex }.map { it.id }
        }
        _selection.value = ids.toSet()
    }

    fun selectedVisibleItems(): List<MediaItem> {
        val ids = _selection.value
        return _state.value.all.filter { it.id in ids }
    }

    fun selectedHiddenItems(): List<MediaItem> {
        val ids = _selection.value
        return _state.value.hidden.filter { it.id in ids }
    }

    fun selectedUris(): List<Uri> = selectedVisibleItems().map { it.uri }

    fun selectedBytes(): Long {
        val ids = _selection.value
        return (_state.value.all + _state.value.hidden).filter { it.id in ids }.sumOf { it.size }
    }

    fun startScan() {
        if (_scan.value.running) return
        scanJob?.cancel()
        _scan.value = ScanState(running = true)
        scanJob = viewModelScope.launch {
            val groups = finder.scan(_state.value.all) { p ->
                _scan.value = _scan.value.copy(progress = p)
            }
            _scan.value = ScanState(running = false, groups = groups, completed = true)
        }
    }

    fun cancelScan() {
        scanJob?.cancel()
        _scan.value = _scan.value.copy(running = false)
    }

    fun resetScan() {
        cancelScan()
        _scan.value = ScanState()
        clearSelection()
    }

    fun trashRequest(uris: List<Uri>) = repo.requestTrash(uris)

    fun onDeletionFinished() {
        clearSelection()
        reload()
    }

    fun prepareHide(items: List<MediaItem>, targetFolder: String, onReady: (List<Uri>) -> Unit) {
        viewModelScope.launch {
            val result = repo.prepareHide(items, targetFolder)
            pendingHiddenPaths = result.createdPaths
            onReady(result.originalUris)
        }
    }

    fun onHideFinished(success: Boolean) {
        if (!success) repo.rollbackHide(pendingHiddenPaths)
        pendingHiddenPaths = emptyList()
        clearSelection()
        reload()
    }

    fun restoreHidden(items: List<MediaItem>) {
        viewModelScope.launch {
            repo.restoreHidden(items)
            clearSelection()
            reload()
        }
    }

    fun createHiddenFolder(name: String) {
        repo.createHiddenFolder(name)
        reload()
    }

    fun renameHiddenFolder(oldName: String, newName: String) {
        repo.renameHiddenFolder(oldName, newName)
        reload()
    }

    fun deleteHiddenFolderIfEmpty(name: String) {
        repo.deleteHiddenFolderIfEmpty(name)
        reload()
    }

    private fun registerObserver() {
        val obs = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) {
                reload()
            }
        }
        observer = obs
        getApplication<Application>().contentResolver.apply {
            registerContentObserver(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, obs)
            registerContentObserver(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, obs)
        }
    }

    override fun onCleared() {
        observer?.let { getApplication<Application>().contentResolver.unregisterContentObserver(it) }
        observer = null
        super.onCleared()
    }
}

fun Long.formatBytes(): String {
    val kb = 1024.0
    val mb = kb * 1024
    val gb = mb * 1024
    return when {
        this >= gb -> String.format("%.1f GB", this / gb)
        this >= mb -> String.format("%.1f MB", this / mb)
        this >= kb -> String.format("%.0f kB", this / kb)
        else -> "$this B"
    }
}
