package com.osmus.gallery.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.osmus.gallery.data.Album
import com.osmus.gallery.data.HiddenAlbum
import com.osmus.gallery.data.MediaItem
import com.osmus.gallery.data.SortOrder

@Composable
fun AlbumsScreen(
    albums: List<Album>,
    columns: Int,
    onOpenAlbum: (Long) -> Unit,
    onOpenAll: () -> Unit,
    onOpenDuplicates: () -> Unit,
    onOpenHidden: () -> Unit,
    onHideAlbum: (Album) -> Unit,
    totalCount: Int,
    hiddenCount: Int,
) {
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text("Galleria", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text(
                    "$totalCount elementi in ${albums.size} cartelle",
                    color = Color(0xFF9A9A97), fontSize = 13.sp,
                )
            }
            IconButton(onClick = onOpenDuplicates) {
                Icon(Icons.Filled.ContentCopy, contentDescription = "Cerca duplicati")
            }
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(columns.coerceIn(2, 4)),
            modifier = Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            item {
                AlbumTile(
                    title = "Tutti gli elementi", count = totalCount,
                    cover = albums.firstOrNull()?.cover, onClick = onOpenAll,
                )
            }
            item {
                AlbumTile(
                    title = "Nascosti", count = hiddenCount,
                    cover = null, onClick = onOpenHidden,
                    badgeIcon = { Icon(Icons.Filled.VisibilityOff, "Nascosti", tint = Color.White) },
                )
            }
            items(albums, key = { it.bucketId }) { album ->
                AlbumTile(
                    title = album.name,
                    count = album.count,
                    cover = album.cover,
                    onClick = { onOpenAlbum(album.bucketId) },
                    menuItems = listOf("Nascondi cartella" to { onHideAlbum(album) }),
                )
            }
        }
    }
}

@Composable
fun HiddenAlbumsScreen(
    albums: List<HiddenAlbum>,
    onOpen: (String) -> Unit,
    onBack: () -> Unit,
    onCreateFolder: (String) -> Unit,
    onRenameFolder: (String, String) -> Unit,
    onRestoreFolder: (String) -> Unit,
    onDeleteEmptyFolder: (String) -> Unit,
    uninstallGuardEnabled: Boolean,
    onEnableUninstallGuard: () -> Unit,
    onDisableUninstallGuard: () -> Unit,
) {
    var createDialog by remember { mutableStateOf(false) }
    var folderName by remember { mutableStateOf("") }
    var renameTarget by remember { mutableStateOf<HiddenAlbum?>(null) }
    var renameValue by remember { mutableStateOf("") }
    var disableGuardDialog by remember { mutableStateOf(false) }
    val hiddenItemCount = albums.sumOf { it.count }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TextButton(onClick = onBack) { Text("Indietro") }
            Column(Modifier.weight(1f)) {
                Text("Nascosti", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("$hiddenItemCount elementi in ${albums.size} cartelle", color = Color(0xFF9A9A97), fontSize = 12.sp)
            }
            IconButton(onClick = { createDialog = true }) {
                Icon(Icons.Filled.Add, contentDescription = "Nuova cartella nascosta")
            }
        }

        Column(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF18191B))
                .padding(14.dp)
        ) {
            Text(
                if (uninstallGuardEnabled) "Protezione disinstallazione: ATTIVA"
                else "Protezione disinstallazione: DISATTIVA",
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp,
            )
            Text(
                if (uninstallGuardEnabled)
                    "Android richiederà di disattivare la protezione prima di poter rimuovere OsmusGallery."
                else
                    "Attivala per evitare di cancellare accidentalmente la Cassaforte disinstallando l'app.",
                color = Color(0xFF9A9A97),
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 4.dp, bottom = 6.dp),
            )
            TextButton(
                onClick = {
                    if (!uninstallGuardEnabled) {
                        onEnableUninstallGuard()
                    } else if (hiddenItemCount > 0) {
                        // Non consentire la disattivazione immediata se la Cassaforte contiene dati.
                        // L'utente è già nella schermata Nascosti: mostriamo un passaggio obbligatorio
                        // di revisione prima di rendere disponibile la conferma finale.
                        disableGuardDialog = true
                    } else {
                        onDisableUninstallGuard()
                    }
                }
            ) {
                Text(if (uninstallGuardEnabled) "Disattiva protezione" else "Attiva protezione")
            }
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            items(albums, key = { it.name }) { album ->
                val actions = buildList<Pair<String, () -> Unit>> {
                    add("Rendi visibile cartella" to { onRestoreFolder(album.name) })
                    add("Rinomina" to {
                        renameTarget = album
                        renameValue = album.name
                    })
                    if (album.count == 0) add("Elimina cartella vuota" to { onDeleteEmptyFolder(album.name) })
                }
                AlbumTile(
                    title = album.name,
                    count = album.count,
                    cover = album.cover,
                    onClick = { onOpen(album.name) },
                    menuItems = actions,
                    badgeIcon = { Icon(Icons.Filled.VisibilityOff, "Nascosta", tint = Color.White) },
                )
            }
        }
    }


    if (disableGuardDialog) {
        AlertDialog(
            onDismissRequest = { disableGuardDialog = false },
            title = { Text("Cassaforte non vuota") },
            text = {
                Text(
                    "Ci sono $hiddenItemCount elementi nascosti. Prima di disattivare la protezione " +
                        "controlla la Cassaforte e rendi visibili o sposta fuori i contenuti che non vuoi rischiare di perdere. " +
                        "La protezione resta attiva finché non confermi esplicitamente la disattivazione."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    disableGuardDialog = false
                    onDisableUninstallGuard()
                }) { Text("Ho controllato, disattiva") }
            },
            dismissButton = {
                TextButton(onClick = { disableGuardDialog = false }) {
                    Text("Resta nella Cassaforte")
                }
            },
        )
    }

    if (createDialog) {
        AlertDialog(
            onDismissRequest = { createDialog = false },
            title = { Text("Nuova cartella nascosta") },
            text = { TextField(value = folderName, onValueChange = { folderName = it }, singleLine = true, label = { Text("Nome") }) },
            confirmButton = {
                TextButton(onClick = {
                    onCreateFolder(folderName)
                    folderName = ""
                    createDialog = false
                }) { Text("Crea") }
            },
            dismissButton = { TextButton(onClick = { createDialog = false }) { Text("Annulla") } },
        )
    }

    renameTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("Rinomina cartella") },
            text = { TextField(value = renameValue, onValueChange = { renameValue = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    onRenameFolder(target.name, renameValue)
                    renameTarget = null
                }) { Text("Rinomina") }
            },
            dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("Annulla") } },
        )
    }
}

@Composable
private fun AlbumTile(
    title: String,
    count: Int,
    cover: android.net.Uri?,
    onClick: () -> Unit,
    menuItems: List<Pair<String, () -> Unit>> = emptyList(),
    badgeIcon: (@Composable () -> Unit)? = null,
) {
    var menuOpen by remember { mutableStateOf(false) }
    Column(Modifier.clip(RoundedCornerShape(10.dp)).combinedClickable(onClick = onClick)) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(1f).background(Color(0xFF1A1B1D))
        ) {
            if (cover != null) {
                AsyncImage(
                    model = cover, contentDescription = title, contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            }
            if (badgeIcon != null) {
                Box(Modifier.align(Alignment.Center)) { badgeIcon() }
            }
            if (menuItems.isNotEmpty()) {
                Box(Modifier.align(Alignment.TopEnd)) {
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(Icons.Filled.MoreVert, "Menu", tint = Color.White)
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        menuItems.forEach { (label, action) ->
                            DropdownMenuItem(text = { Text(label) }, onClick = {
                                menuOpen = false
                                action()
                            })
                        }
                    }
                }
            }
        }
        Text(title, maxLines = 1, fontSize = 13.sp, fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(start = 4.dp, top = 6.dp))
        Text("$count", fontSize = 11.sp, color = Color(0xFF8A8A88),
            modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
    }
}

@Composable
fun PhotoGridScreen(
    title: String,
    items: List<MediaItem>,
    columns: Int,
    squareThumbs: Boolean,
    sort: SortOrder,
    selection: Set<Long>,
    hiddenMode: Boolean = false,
    onBack: (() -> Unit)? = null,
    onColumnsChange: (Int) -> Unit,
    onSortChange: (SortOrder) -> Unit,
    onToggleSquare: () -> Unit,
    onOpen: (Int) -> Unit,
    onToggleSelect: (Long) -> Unit,
    onHideSelected: () -> Unit = {},
    onRestoreSelected: () -> Unit = {},
) {
    var menuOpen by remember { mutableStateOf(false) }
    var pinchAccumulator by remember { mutableStateOf(1f) }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (onBack != null) TextButton(onClick = onBack) { Text("Indietro") }
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(
                    if (selection.isEmpty()) "${items.size} elementi" else "${selection.size} selezionati",
                    fontSize = 12.sp, color = Color(0xFF9A9A97),
                )
            }
            if (selection.isNotEmpty()) {
                IconButton(onClick = if (hiddenMode) onRestoreSelected else onHideSelected) {
                    Icon(
                        if (hiddenMode) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                        contentDescription = if (hiddenMode) "Rendi visibile" else "Nascondi",
                    )
                }
            }
            Box {
                IconButton(onClick = { menuOpen = true }) {
                    Icon(Icons.Filled.Sort, contentDescription = "Ordina")
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    SortOrder.entries.forEach { option ->
                        DropdownMenuItem(
                            text = { Text(option.label, fontWeight = if (option == sort) FontWeight.Bold else FontWeight.Normal) },
                            onClick = { onSortChange(option); menuOpen = false },
                        )
                    }
                    DropdownMenuItem(
                        text = { Text(if (squareThumbs) "Anteprime intere" else "Ritaglia anteprime in quadrati") },
                        onClick = { onToggleSquare(); menuOpen = false },
                    )
                }
            }
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(columns),
            modifier = Modifier.fillMaxSize().pointerInput(Unit) {
                detectTransformGestures { _, _, zoom, _ ->
                    pinchAccumulator *= zoom
                    if (pinchAccumulator > 1.35f) {
                        onColumnsChange(columns - 1); pinchAccumulator = 1f
                    } else if (pinchAccumulator < 0.74f) {
                        onColumnsChange(columns + 1); pinchAccumulator = 1f
                    }
                }
            },
            contentPadding = androidx.compose.foundation.layout.PaddingValues(2.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            items(items.size, key = { items[it].id }) { index ->
                val item = items[index]
                MediaThumb(
                    item = item, square = squareThumbs,
                    selected = item.id in selection, selectionActive = selection.isNotEmpty(),
                    onClick = { if (selection.isNotEmpty()) onToggleSelect(item.id) else onOpen(index) },
                    onLongClick = { onToggleSelect(item.id) },
                )
            }
        }
    }
}

@Composable
private fun MediaThumb(
    item: MediaItem,
    square: Boolean,
    selected: Boolean,
    selectionActive: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
) {
    Box(
        Modifier.fillMaxWidth().aspectRatio(1f).background(Color(0xFF151618))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        AsyncImage(
            model = ImageRequest.Builder(androidx.compose.ui.platform.LocalContext.current)
                .data(item.uri).crossfade(false).build(),
            contentDescription = item.name,
            contentScale = if (square) ContentScale.Crop else ContentScale.Fit,
            modifier = Modifier.fillMaxSize(),
        )
        if (item.isVideo) {
            Icon(Icons.Filled.PlayCircle, "Video", tint = Color.White.copy(alpha = 0.85f),
                modifier = Modifier.align(Alignment.BottomStart).padding(4.dp).size(18.dp))
        }
        if (item.isGif) {
            Text("GIF", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.BottomStart)
                    .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(3.dp))
                    .padding(horizontal = 4.dp, vertical = 1.dp))
        }
        if (item.hidden) {
            Icon(Icons.Filled.VisibilityOff, "Nascosto", tint = Color.White,
                modifier = Modifier.align(Alignment.TopStart).padding(4.dp).size(17.dp))
        }
        if (selectionActive) {
            Box(Modifier.fillMaxSize().background(if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.32f) else Color.Transparent))
            if (selected) {
                Icon(Icons.Filled.CheckCircle, "Selezionato", tint = Color.White,
                    modifier = Modifier.align(Alignment.TopEnd).padding(4.dp).size(20.dp))
            }
        }
    }
}
