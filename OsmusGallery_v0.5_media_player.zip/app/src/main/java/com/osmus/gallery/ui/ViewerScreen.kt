package com.osmus.gallery.ui

import android.content.Intent
import android.os.Build
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.decode.GifDecoder
import coil.decode.ImageDecoderDecoder
import coil.request.ImageRequest
import com.osmus.gallery.data.MediaItem
import com.osmus.gallery.data.effectiveDate
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ViewerScreen(
    items: List<MediaItem>,
    startIndex: Int,
    onClose: () -> Unit,
    onDelete: (MediaItem) -> Unit,
    onHide: (MediaItem) -> Unit = {},
    onRestore: (MediaItem) -> Unit = {},
) {
    if (items.isEmpty()) {
        onClose()
        return
    }
    val context = LocalContext.current
    val pagerState = rememberPagerState(
        initialPage = startIndex.coerceIn(0, items.lastIndex),
        pageCount = { items.size },
    )
    var chromeVisible by remember { mutableStateOf(true) }
    var detailsVisible by remember { mutableStateOf(false) }

    val current = items.getOrNull(pagerState.currentPage) ?: items.first()

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize(),
        ) { page ->
            val item = items[page]
            MediaPage(
                item = item,
                isActive = pagerState.currentPage == page,
                onTap = { chromeVisible = !chromeVisible },
            )
        }

        AnimatedVisibility(visible = chromeVisible, modifier = Modifier.align(Alignment.TopCenter)) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.55f))
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onClose) {
                    Icon(Icons.Filled.Close, "Chiudi", tint = Color.White)
                }
                Column(Modifier.weight(1f).padding(start = 4.dp)) {
                    Text(
                        current.name,
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                    )
                    Text(
                        "${pagerState.currentPage + 1} di ${items.size}",
                        color = Color(0xFFB9B9B7),
                        fontSize = 11.sp,
                    )
                }
                IconButton(onClick = { detailsVisible = !detailsVisible }) {
                    Icon(Icons.Filled.Info, "Dettagli", tint = Color.White)
                }
                IconButton(onClick = {
                    val share = Intent(Intent.ACTION_SEND).apply {
                        type = current.mimeType
                        val shareUri = if (current.hidden && current.localPath != null) {
                            FileProvider.getUriForFile(
                                context, context.packageName + ".fileprovider", File(current.localPath)
                            )
                        } else current.uri
                        putExtra(Intent.EXTRA_STREAM, shareUri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(share, "Condividi"))
                }) {
                    Icon(Icons.Filled.Share, "Condividi", tint = Color.White)
                }
                IconButton(onClick = { if (current.hidden) onRestore(current) else onHide(current) }) {
                    Icon(
                        if (current.hidden) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                        if (current.hidden) "Rendi visibile" else "Nascondi",
                        tint = Color.White,
                    )
                }
                if (!current.hidden) {
                    IconButton(onClick = { onDelete(current) }) {
                        Icon(Icons.Filled.Delete, "Elimina", tint = Color.White)
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = detailsVisible,
            modifier = Modifier.align(Alignment.BottomCenter),
        ) {
            DetailsPanel(current)
        }
    }
}

@Composable
private fun MediaPage(item: MediaItem, isActive: Boolean, onTap: () -> Unit) {
    when {
        item.isVideo -> VideoPlayer(item = item, isActive = isActive, onTap = onTap)
        item.isGif -> GifViewer(item = item, onTap = onTap)
        else -> ZoomableImage(item = item, onTap = onTap)
    }
}

@Composable
private fun VideoPlayer(item: MediaItem, isActive: Boolean, onTap: () -> Unit) {
    val context = LocalContext.current
    val player = remember(item.uri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(ExoMediaItem.fromUri(item.uri))
            repeatMode = Player.REPEAT_MODE_OFF
            prepare()
        }
    }

    LaunchedEffect(isActive) {
        if (!isActive) player.pause()
    }

    DisposableEffect(player) {
        onDispose { player.release() }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                PlayerView(ctx).apply {
                    this.player = player
                    useController = true
                    controllerAutoShow = true
                    controllerHideOnTouch = true
                    controllerShowTimeoutMs = 3000
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                    setOnClickListener { onTap() }
                }
            },
            update = { view ->
                view.player = player
            },
        )
    }
}

@Composable
private fun GifViewer(item: MediaItem, onTap: () -> Unit) {
    val context = LocalContext.current
    val gifLoader = remember(context) {
        ImageLoader.Builder(context)
            .components {
                if (Build.VERSION.SDK_INT >= 28) add(ImageDecoderDecoder.Factory())
                else add(GifDecoder.Factory())
            }
            .build()
    }
    val request = remember(item.uri) {
        ImageRequest.Builder(context)
            .data(item.uri)
            .crossfade(false)
            .build()
    }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(item.id) {
                detectTapGestures(onTap = { onTap() })
            }
    ) {
        AsyncImage(
            model = request,
            imageLoader = gifLoader,
            contentDescription = item.name,
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize(),
        )
    }
}

@Composable
private fun ZoomableImage(item: MediaItem, onTap: () -> Unit) {
    var scale by remember(item.id) { mutableFloatStateOf(1f) }
    var offsetX by remember(item.id) { mutableFloatStateOf(0f) }
    var offsetY by remember(item.id) { mutableFloatStateOf(0f) }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(item.id) {
                detectTapGestures(
                    onTap = { onTap() },
                    onDoubleTap = {
                        if (scale > 1f) {
                            scale = 1f
                            offsetX = 0f
                            offsetY = 0f
                        } else {
                            scale = 2.5f
                        }
                    },
                )
            }
            .pointerInput(item.id) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(1f, 8f)
                    if (scale > 1f) {
                        offsetX += pan.x
                        offsetY += pan.y
                    } else {
                        offsetX = 0f
                        offsetY = 0f
                    }
                }
            }
    ) {
        AsyncImage(
            model = item.uri,
            contentDescription = item.name,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(
                    scaleX = scale,
                    scaleY = scale,
                    translationX = offsetX,
                    translationY = offsetY,
                ),
        )
    }
}

@Composable
private fun DetailsPanel(item: MediaItem) {
    val fmt = remember { SimpleDateFormat("d MMMM yyyy, HH:mm", Locale.getDefault()) }
    Column(
        Modifier
            .fillMaxWidth()
            .background(Color.Black.copy(alpha = 0.82f))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        DetailRow("Nome", item.name)
        DetailRow("Cartella", item.bucketName.ifBlank { "-" })
        DetailRow("Data", fmt.format(Date(item.effectiveDate())))
        DetailRow("Dimensione", item.size.formatBytes())
        if (item.width > 0 && item.height > 0) {
            DetailRow("Risoluzione", "${item.width} x ${item.height}")
        }
        if (item.durationMs > 0) {
            val s = item.durationMs / 1000
            DetailRow("Durata", "%d:%02d".format(s / 60, s % 60))
        }
        DetailRow("Tipo", item.mimeType)
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth()) {
        Text(label, color = Color(0xFF8F8F8D), fontSize = 12.sp, modifier = Modifier.weight(0.35f))
        Text(value, color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(0.65f))
    }
}
